
package clases;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Inventario inventario = new Inventario();
        Scanner sc = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n=== SISTEMA DE INVENTARIO ===");
            System.out.println("1. Agregar producto");
            System.out.println("2. Buscar producto por nombre");
            System.out.println("3. Listar productos");
            System.out.println("4. Eliminar producto por ID");
            System.out.println("5. Calcular stock total");
            System.out.println("6. Salir");
            System.out.print("Seleccione una opción: ");

            opcion = sc.nextInt();
            sc.nextLine(); // limpiar buffer

            switch (opcion) {

                case 1:
                    System.out.print("ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Nombre: ");
                    String nombre = sc.nextLine();
                    System.out.print("Precio: ");
                    double precio = sc.nextDouble();
                    System.out.print("Cantidad: ");
                    int cantidad = sc.nextInt();
                    inventario.agregarProducto(new Producto(id, nombre, precio, cantidad));
                    break;

                case 2:
                    System.out.print("Nombre a buscar: ");
                    String buscar = sc.nextLine();
                    Producto encontrado = inventario.buscarPorNombre(buscar);
                    System.out.println(encontrado != null ? encontrado : "No encontrado.");
                    break;

                case 3:
                    inventario.listarProductos();
                    break;

                case 4:
                    System.out.print("ID a eliminar: ");
                    int idEliminar = sc.nextInt();
                    inventario.eliminarProducto(idEliminar);
                    break;

                case 5:
                    System.out.println("Stock total: " + inventario.calcularStockTotal());
                    System.out.println("Valor total: " + inventario.calcularValorTotal());
                    break;

                case 6:
                    System.out.println("Saliendo del sistema...");
                    break;

                default:
                    System.out.println("Opción inválida.");
            }

        } while (opcion != 6);

        sc.close();
    }
}