package clases;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class InventarioTest {

    @Test
    void testAgregarProducto() {
        Inventario inv = new Inventario();
        inv.agregarProducto(new Producto(1, "Pan", 1000, 10));
        assertEquals(10, inv.calcularStockTotal());
    }

    @Test
    void testBuscarProducto() {
        Inventario inv = new Inventario();
        inv.agregarProducto(new Producto(1, "Pan", 1000, 10));
        assertNotNull(inv.buscarPorNombre("Pan"));
        assertNull(inv.buscarPorNombre("Leche"));
    }

    @Test
    void testEliminarProducto() {
        Inventario inv = new Inventario();
        inv.agregarProducto(new Producto(1, "Pan", 1000, 10));
        assertTrue(inv.eliminarProducto(1));
        assertFalse(inv.eliminarProducto(99));
    }

    @Test
    void testCalculos() {
        Inventario inv = new Inventario();
        inv.agregarProducto(new Producto(1, "Pan", 1000, 10));
        inv.agregarProducto(new Producto(2, "Leche", 4000, 5));

        assertEquals(15, inv.calcularStockTotal());
        assertEquals(10*1000 + 5*4000, inv.calcularValorTotal());
    }
}
